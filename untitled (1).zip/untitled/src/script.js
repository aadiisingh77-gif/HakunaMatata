



// Force dark background on page load + after a tiny delay (helps with CodePen glitches)
document.addEventListener('DOMContentLoaded', function() {
    // Option 1: Deep romantic purple-black gradient
    document.body.style.background = 'linear-gradient(135deg, #1a0033, #2c003e, #000000)';

    // Option 2: Pure black (uncomment if you prefer)
    // document.body.style.background = '#000000';

    // Option 3: Black with subtle red tint (uncomment if you want)
    // document.body.style.background = 'linear-gradient(135deg, #0f000a, #1a0000, #000000)';

    // Optional: Also darken container & note for better contrast on dark bg
    const container = document.querySelector('.container');
    if (container) {
        container.style.background = 'rgba(10, 0, 30, 0.6)';
    }

    const note = document.querySelector('.note');
    if (note) {
        note.style.background = 'rgba(20, 0, 50, 0.7)';
        note.style.borderColor = '#9b30ff';
    }

    // Extra force after 500ms (in case CodePen preview reloads styles)
    setTimeout(function() {
        document.body.style.background = 'linear-gradient(135deg, #1a0033, #2c003e, #000000) !important';
    }, 500);
});